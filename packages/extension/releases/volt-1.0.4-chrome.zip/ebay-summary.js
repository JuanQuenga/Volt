var ebaySummary=(function(){"use strict";function G(e){return e}const C="sidepanel.html",v="__scoutSidePanelCtx__";function x(){const e=globalThis;return e[v]||(e[v]={state:{open:!1,tool:null},listenersAttached:!1}),e[v]}function S(e){if(e.tabId!==void 0)return;const o=()=>{if(e.tabId===void 0)try{chrome.runtime.sendMessage({action:"getSidePanelStateForTab"},n=>{!chrome.runtime.lastError&&n?.success?(typeof n?.tabId=="number"&&(e.tabId=n.tabId,console.log(`[Scout] Sidepanel context initialized with tabId: ${e.tabId}`)),n?.state&&(e.state=k(n.state))):setTimeout(o,1e3)})}catch{setTimeout(o,2e3)}};o(),A(e)}function A(e){if(!e.listenersAttached){try{chrome.runtime.onMessage.addListener((o,n,i)=>(o?.action==="sidePanelStateSync"&&(e.state=k(o?.state),i({ok:!0})),!1))}catch{}e.listenersAttached=!0}}function k(e){return!e||typeof e!="object"?{open:!1,tool:null}:{open:!!e.open,tool:typeof e.tool=="string"?e.tool:null}}function B(e){if(chrome?.sidePanel?.setOptions)try{const o={enabled:!0,path:C};typeof e=="number"&&(o.tabId=e),chrome.sidePanel.setOptions(o,()=>{const n=chrome.runtime.lastError;n&&console.warn("[Scout] setOptions warning:",n.message)})}catch{}}function I(e){return new Promise((o,n)=>{if(!chrome?.sidePanel?.open){n(new Error("sidePanel API unavailable"));return}try{const i={};typeof e=="number"&&(i.tabId=e),chrome.sidePanel.open(i,()=>{const s=chrome.runtime.lastError;s?n(s):o()})}catch(i){n(i)}})}function $(e){return new Promise((o,n)=>{if(!chrome?.sidePanel?.close){n(new Error("sidePanel API unavailable"));return}try{const i={};typeof e=="number"&&(i.tabId=e),chrome.sidePanel.close(i,()=>{const s=chrome.runtime.lastError;s?n(s):o()})}catch(i){n(i)}})}function h(e,o,n,i,s){try{chrome.runtime.sendMessage({action:"sidePanelToggleResult",status:e,tabId:o,tool:n,source:i,error:s},()=>{chrome.runtime.lastError})}catch{}}function P(){const e=!!chrome?.sidePanel?.open;return console.log(`[Scout] sidePanel API available: ${e}, tabId: ${x().tabId}`),e}function U(){try{const e=x();S(e)}catch{}}function O(e,o){if(!P())return Promise.reject(new Error("sidePanel API unavailable"));const n=x();S(n);const i=n.tabId,s=n.state||{open:!1,tool:null},m=s.open&&s.tool===e;return new Promise((y,b)=>{if(m){$(i).then(()=>{n.state={open:!1,tool:null},h("closed",i,e,o?.source),y("closed")}).catch(u=>{h("error",i,e,o?.source,u?.message),b(u)});return}try{chrome.storage?.local?.set?.({sidePanelTool:e,sidePanelUrl:null})}catch{}n.state={open:!0,tool:e},B(i),I(i).then(()=>{h("opened",i,e,o?.source),y("opened")}).catch(u=>{console.error("[Scout] execOpen failed:",u),n.state={open:!1,tool:null},h("error",i,e,o?.source,u?.message),b(u)})})}const T={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){if(!window.location.hostname.includes("ebay.com")||!window.location.pathname.startsWith("/sch/")){console.log("⚡ [Volt eBay Summary] Not on eBay search page, exiting");return}U(),console.log("⚡ [Volt eBay Summary] SCRIPT LOADED");const e="volt-ebay-summary",o="volt-ebay-summary-style";let n=!1,i=!1;const s=(...t)=>{try{console.log("[Volt eBay Summary]",...t)}catch{}},m=t=>{try{chrome.runtime.sendMessage({action:"openInSidebar",tool:t})}catch{}},y=t=>{if(!P()){m(t);return}try{O(t,{source:"ebay-summary"}).catch(l=>{s("sidepanel trigger failed",l?.message||l),m(t)})}catch(l){s("sidepanel trigger threw",l?.message||l),m(t)}},b=()=>{if(document.getElementById(o))return;const t=document.createElement("style");t.id=o,t.textContent=`
        #${e} {
          width: 100%;
          padding: 12px 16px;
          padding-right: 110px; /* Make space for buttons */
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 4px 12px rgba(15, 23, 42, 0.05);
          position: relative;
          box-sizing: border-box;
          display: flex;
          flex-direction: row;
          align-items: center;
          flex-wrap: wrap;
          gap: 12px;
        }
        
        /* Green theme for Sold Listings */
        #${e}.volt-state-sold {
          border: 1px solid #16a34a; /* Green-600 */
          background: #f0fdf4; /* Green-50 */
        }
        
        /* Orange theme for Active/Completed Listings (Warning) */
        #${e}.volt-state-active {
          border: 1px solid #f97316; /* Orange-500 */
          background: #fff7ed; /* Orange-50 */
        }

        #${e} h2 {
          font-size: 16px;
          margin: 0;
          font-weight: 700;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 6px;
          white-space: nowrap;
          flex-shrink: 0;
        }
        #${e} h2 img {
          width: 20px;
          height: 20px;
        }
        #${e} .volt-ebay-summary__content {
          font-size: 15px;
          color: #334155;
          line-height: 1.5;
          display: inline;
        }
        #${e} .volt-ebay-summary__content strong {
          color: #0f172a;
          font-weight: 700;
        }
        #${e} .volt-ebay-summary__action {
          display: inline-block;
          margin-left: 8px;
          font-weight: 600;
          text-decoration: underline;
          cursor: pointer;
          color: #c2410c; /* Orange-700 */
          font-size: 15px;
        }
        #${e} .volt-ebay-summary__action:hover {
          color: #9a3412; /* Orange-800 */
        }

        #${e} .volt-ebay-summary__links {
          display: inline;
          margin-left: 6px;
          color: #475569;
        }
        #${e} .volt-ebay-summary__links a {
          color: #15803d; /* Green-700 */
          text-decoration: underline;
          font-weight: 600;
          cursor: pointer;
        }
        #${e} .volt-ebay-summary__links a:hover {
          color: #166534; /* Green-800 */
        }

        /* Tooltip styles */
        #${e} [data-tooltip] {
          position: relative;
        }
        #${e} [data-tooltip]:hover::after {
          content: attr(data-tooltip);
          position: absolute;
          bottom: 100%;
          left: 50%;
          transform: translateX(-50%);
          margin-bottom: 8px;
          padding: 4px 8px;
          background: #0f172a;
          color: #f8fafc;
          border-radius: 4px;
          font-size: 12px;
          font-weight: 500;
          white-space: nowrap;
          z-index: 20;
          pointer-events: none;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        #${e} .volt-ebay-summary__dismiss {
          position: absolute;
          top: 12px;
          right: 12px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.1);
          color: #dc2626;
        }
        
        #${e} .volt-ebay-summary__sidepanel {
          position: absolute;
          top: 12px;
          right: 76px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__sidepanel:hover {
          background: rgba(59, 130, 246, 0.1);
          color: #2563eb;
        }
        
        #${e} .volt-ebay-summary__settings {
          position: absolute;
          top: 12px;
          right: 44px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__settings:hover {
          background: rgba(59, 130, 246, 0.1);
          color: #2563eb;
        }
      `,document.head.appendChild(t)},u=()=>{try{const t=new URL(window.location.href);if(!/\.ebay\./i.test(t.hostname)||!t.pathname.startsWith("/sch/"))return"unknown";const l=t.searchParams.get("LH_Sold"),c=t.searchParams.get("LH_Complete"),r=l==="1"||l==="true",a=c==="1"||c==="true";return r?"sold":a?"completed":"active"}catch{return"active"}},R=t=>{if(!t)return"All Conditions";const c=decodeURIComponent(t).split("|"),r=new Set;if(c.forEach(d=>{["1000","3","10"].includes(d)?r.add("New"):["1500","1750"].includes(d)?r.add("Open Box"):d>="2000"&&d<="2500"?r.add("Refurbished"):["3000","4","5000","6000"].includes(d)?r.add("Used"):["7000"].includes(d)?r.add("For Parts"):r.add("Other")}),r.size===0)return"All Conditions";const a=Array.from(r);return a.length<=2?a.join(" & "):a.join(", ")},_=()=>{const t=document.getElementById(e);t&&t.remove()},w=t=>{const c=t.target.closest("[data-action]");if(!c)return;const r=c.getAttribute("data-action");if(r){if(t.preventDefault(),t.stopPropagation(),r==="open-sidepanel")y("ebay-sold-tool");else if(r==="settings")chrome.runtime.sendMessage({action:"open-settings",section:"ebay"});else if(r==="dismiss")i=!0,_();else if(r==="switch-to-sold"){const a=new URL(window.location.href);a.searchParams.set("LH_Sold","1"),a.searchParams.set("LH_Complete","1"),window.location.href=a.toString()}else if(r==="filter-used"){const a=new URL(window.location.href);a.searchParams.set("LH_ItemCondition","3000"),window.location.href=a.toString()}else if(r==="filter-new"){const a=new URL(window.location.href);a.searchParams.set("LH_ItemCondition","1000"),window.location.href=a.toString()}else if(r==="filter-broken"){const a=new URL(window.location.href);a.searchParams.set("LH_ItemCondition","7000"),window.location.href=a.toString()}else if(r==="filter-all"){const a=new URL(window.location.href);a.searchParams.delete("LH_ItemCondition"),window.location.href=a.toString()}}},H=()=>{let t=document.getElementById(e);if(t)return t;const l=document.querySelector(".srp-river-answer--NAVIGATION_ANSWER_COLLAPSIBLE_CAROUSEL");if(l&&l.parentElement)return t=document.createElement("section"),t.id=e,t.addEventListener("click",w),l.parentElement.insertBefore(t,l.nextSibling),s("✓ Summary container inserted after .srp-river-answer--NAVIGATION_ANSWER_COLLAPSIBLE_CAROUSEL"),t;const c=document.querySelector(".srp-controls__row-2");if(c)return t=document.createElement("section"),t.id=e,t.addEventListener("click",w),c.appendChild(t),s("✓ Summary container inserted into .srp-controls__row-2"),t;const r=document.getElementById("srp-river-results");if(r&&r.parentElement)return t=document.createElement("section"),t.id=e,t.addEventListener("click",w),r.parentElement.insertBefore(t,r),s("✓ Summary container inserted before #srp-river-results (fallback)"),t;const a=document.getElementById("mainContent");return a?(t=document.createElement("section"),t.id=e,t.addEventListener("click",w),a.prepend(t),s("✓ Summary container inserted into #mainContent (last resort)"),t):(s("✗ Cannot insert summary - no suitable parent found"),null)},L=async()=>{n=!1;try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){s("✗ eBay Summary feature is disabled in settings"),_();return}}catch(E){s("⚠️ Failed to check settings, assuming enabled",E)}if(i){_();return}b();const t=H();if(!t)return;const l=u(),c=l==="sold",a=new URL(window.location.href).searchParams.get("LH_ItemCondition");t.className=c?"volt-state-sold":"volt-state-active";let d="Active Listings";l==="sold"?d="Sold Listings":l==="completed"&&(d="Completed Listings (Sold & Unsold)");const f=R(a),N=chrome.runtime.getURL("assets/icons/logo-32.png");let p=`
        You are currently viewing <strong>${d}</strong> for <strong>${f}</strong> items.
      `;c?f==="All Conditions"?p+=`
            <span class="volt-ebay-summary__links">
              Filter by <a data-action="filter-used">Used</a>, <a data-action="filter-new">New</a>, or <a data-action="filter-broken">Broken</a>.
            </span>
          `:f.includes("New")?p+=`
            <span class="volt-ebay-summary__links">
              Switch to <a data-action="filter-used">Used</a> or <a data-action="filter-broken">Broken</a>.
            </span>
          `:f.includes("Used")?p+=`
            <span class="volt-ebay-summary__links">
              Switch to <a data-action="filter-new">New</a> or <a data-action="filter-broken">Broken</a>.
            </span>
          `:f.includes("For Parts")&&(p+=`
            <span class="volt-ebay-summary__links">
              Switch to <a data-action="filter-new">New</a> or <a data-action="filter-used">Used</a>.
            </span>
          `):p+=`
          <span class="volt-ebay-summary__links">
            Ready to analyze prices? <a data-action="switch-to-sold">Switch to Sold Listings</a>.
          </span>
        `;const M=`
        <button class="volt-ebay-summary__sidepanel" data-action="open-sidepanel" data-tooltip="Open eBay Tool">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
          </svg>
        </button>
      `,V=`
        <button class="volt-ebay-summary__settings" data-action="settings" data-tooltip="Settings">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
        </button>
      `,F=`
        <button class="volt-ebay-summary__dismiss" data-action="dismiss" data-tooltip="Dismiss">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      `;t.innerHTML=`
        <h2>
          <img src="${N}" alt="Volt Logo" />
          eBay Summary
        </h2>
        <div class="volt-ebay-summary__content">
          ${p}
        </div>
        ${M}
        ${V}
        ${F}
      `};new MutationObserver(()=>{n||(n=!0,requestAnimationFrame(()=>{document.getElementById(e)||L()}))}).observe(document.body,{childList:!0,subtree:!0}),L()}};function D(){}function g(e,...o){}const z={debug:(...e)=>g(console.debug,...e),log:(...e)=>g(console.log,...e),warn:(...e)=>g(console.warn,...e),error:(...e)=>g(console.error,...e)};return(async()=>{try{return await T.main()}catch(e){throw z.error('The unlisted script "ebay-summary" crashed on startup!',e),e}})()})();
ebaySummary;