var shopifyButtons=(function(){"use strict";function I(i){return i}const q={matches:["https://admin.shopify.com/*","https://*.myshopify.com/admin/*"],runAt:"document_idle",allFrames:!1,main(){const i=(...t)=>{try{console.log("[Scout Quick Actions]",...t)}catch{}},b={ebay:chrome.runtime.getURL("assets/logos/ebay.svg"),pricecharting:chrome.runtime.getURL("assets/logos/pricecharting.webp")},E=`
      .scout-quick-actions-overlay {
        position: fixed;
        z-index: 100; /* Lowered to allow modals to cover it */
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none; /* Allow clicking through gaps */
        transition: opacity 0.2s ease;
      }

      .scout-action-tab {
        width: 48px;
        height: 120px;
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        color: white;
        box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
        pointer-events: auto;
        position: relative;
        flex-shrink: 0;
      }

      .scout-action-tab img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1)) brightness(0) invert(1);
      }

      .scout-action-tab:hover {
        transform: translateX(-4px);
        box-shadow: -4px 0 12px rgba(0, 0, 0, 0.15);
        width: 52px;
      }

      .scout-action-tab:active {
        transform: translateX(-2px);
      }

      .scout-action-tab.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        filter: grayscale(1);
        transform: none !important;
        width: 48px !important;
      }

      /* eBay Tab - Green */
      .scout-tab-ebay {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%); /* Green */
      }

      /* PriceCharting Tab - Blue */
      .scout-tab-pricecharting {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); /* Blue */
      }

      /* Tooltip */
      .scout-action-tab::after {
        content: attr(data-tooltip);
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        margin-left: 12px;
        background-color: #202223;
        color: white;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.2s ease;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        visibility: hidden;
      }

      .scout-action-tab:hover::after {
        opacity: 1;
        visibility: visible;
        margin-left: 16px;
      }
    `,P=()=>{if(!document.getElementById("scout-quick-actions-styles")){const t=document.createElement("style");t.textContent=E,t.id="scout-quick-actions-styles",(document.head||document.documentElement).appendChild(t)}};let d=null,a=null,h=null,u=null,s=null,r=null,g=!1;const L=()=>{const t=document.querySelector('input[name="title"]');if(t){const n=t.closest("form");if(n)return i("Found main product form for Shopify quick actions"),n;let e=t.parentElement;for(;e&&e!==document.body;){const o=(e.className||"").toString();if(o.includes("Polaris-ShadowBevel")||o.includes("Polaris-LegacyCard")||o.includes("Polaris-Card"))return e;if(e.tagName==="SECTION"||o.includes("Polaris-Box")){const c=window.getComputedStyle(e);if(c.backgroundColor==="rgb(255, 255, 255)"&&c.boxShadow!=="none")return e}e=e.parentElement}}return null},y=t=>{if(!t)return null;const n=t.querySelector('[class*="_ReadField_"]');if(n&&!n.className.includes("placeholder"))return n.textContent?.trim()||null;const e=t.querySelector("input");return e?e.value:null},w=()=>{const t=document.querySelector('[id*="metafields.custom.mpn"]')||document.querySelector('[id*="metafields.custom.manufacturer_part_number"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(e=>{const o=e.querySelector("label");return o&&o.textContent.includes("MPN")});if(a=y(t),h=a?"MPN":null,!a){const e=document.querySelector('[id*="metafields.custom.model"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(c=>{const l=c.querySelector("label");return l&&l.textContent.includes("Model")}),o=y(e);o&&(a=o,h="Model")}const n=document.querySelector('[id*="metafields.custom.upc"]')||document.querySelector('[id*="metafields.custom.barcode"]')||document.querySelector('[id*="metafields.barcode"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(e=>{const o=e.querySelector("label");return o&&(o.textContent.includes("UPC")||o.textContent.includes("Barcode"))});u=y(n)},x=t=>{r&&!r.closed&&r.close();const n=1100,e=800,o=(window.screen.width-n)/2,c=(window.screen.height-e)/2;r=window.open(t,"scout_search_popup",`width=${n},height=${e},left=${o},top=${c},resizable=yes,scrollbars=yes`)},B=()=>{if(document.getElementById("scout-quick-actions-overlay"))return;s=document.createElement("div"),s.id="scout-quick-actions-overlay",s.className="scout-quick-actions-overlay",s.style.opacity="0";const t=document.createElement("div");t.className="scout-action-tab scout-tab-pricecharting",t.id="scout-tab-pc";const n=document.createElement("img");n.src=b.pricecharting,n.alt="PriceCharting",t.appendChild(n),t.onclick=c=>{if(c.stopPropagation(),u){const l=`https://www.pricecharting.com/search-products?q=${encodeURIComponent(u)}&type=videogames`;x(l)}else alert("No UPC found")};const e=document.createElement("div");e.className="scout-action-tab scout-tab-ebay",e.id="scout-tab-ebay";const o=document.createElement("img");o.src=b.ebay,o.alt="eBay",e.appendChild(o),e.onclick=c=>{if(c.stopPropagation(),a){const l=`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(a)}&LH_Sold=1&LH_Complete=1&_dmd=2&rt=nc`;x(l)}else alert("No MPN or Model found")},s.appendChild(t),s.appendChild(e),document.body.appendChild(s)},A=()=>{if(d||(d=L(),!d&&!g&&(g=!0,i("Could not find main product card, showing Shopify quick actions in fallback position."))),!s)return;if(!d){s.style.opacity="0";return}const t=d.getBoundingClientRect();if(t.width===0||t.height===0||t.width<300||t.height<200){s.style.opacity="0";return}const c=t.left-48,l=t.top+60;s.style.left=`${c}px`,s.style.top=`${l}px`,s.style.opacity="1";const p=document.getElementById("scout-tab-pc"),m=document.getElementById("scout-tab-ebay");if(p&&(u?(p.classList.remove("disabled"),p.setAttribute("data-tooltip",`Search PriceCharting with UPC: ${u}`)):(p.classList.add("disabled"),p.setAttribute("data-tooltip","No UPC found"))),m)if(a){m.classList.remove("disabled");const M=h==="Model"?"Model":"MPN";m.setAttribute("data-tooltip",`Search eBay(sold prices) with ${M}: ${a}`)}else m.classList.add("disabled"),m.setAttribute("data-tooltip","No MPN or Model found")},v=()=>{A(),requestAnimationFrame(v)},S=()=>{i("Initializing Shopify Quick Actions content script"),P(),window.addEventListener("focus",()=>{r&&!r.closed&&(r.close(),r=null)}),new MutationObserver(()=>{w()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value","class"]}),B(),requestAnimationFrame(v),setInterval(w,2e3)},C=()=>{chrome.storage.sync.get(["cmdkSettings"],t=>{((t.cmdkSettings||{}).shopifyButtons?.enabled??!0)&&S()})};chrome.runtime.onMessage.addListener((t,n,e)=>{if(t.action==="shopify-buttons-settings-changed")if(t.enabled)if(!document.getElementById("scout-quick-actions-overlay"))S();else{const o=document.getElementById("scout-quick-actions-overlay");o&&(o.style.display="flex")}else{const o=document.getElementById("scout-quick-actions-overlay");o&&(o.style.display="none")}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",C):C()}};function N(){}function f(i,...b){}const k={debug:(...i)=>f(console.debug,...i),log:(...i)=>f(console.log,...i),warn:(...i)=>f(console.warn,...i),error:(...i)=>f(console.error,...i)};return(async()=>{try{return await q.main()}catch(i){throw k.error('The unlisted script "shopify-buttons" crashed on startup!',i),i}})()})();
shopifyButtons;