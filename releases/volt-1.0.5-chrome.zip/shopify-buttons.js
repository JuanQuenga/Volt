var shopifyButtons=(function(){"use strict";function E(i){return i}const x={matches:["https://admin.shopify.com/*","https://*.myshopify.com/admin/*"],runAt:"document_idle",allFrames:!1,main(){const i={ebay:chrome.runtime.getURL("assets/logos/ebay.svg"),pricecharting:chrome.runtime.getURL("assets/logos/pricecharting.webp")},m=`
      .scout-quick-actions-overlay {
        position: fixed;
        z-index: 100; /* Lowered to allow modals to cover it */
        display: flex;
        flex-direction: column;
        gap: 8px;
        pointer-events: none; /* Allow clicking through gaps */
        transition: opacity 0.2s ease;
      }

      .scout-action-tab {
        width: 48px;
        height: 120px;
        border-top-left-radius: 8px;
        border-bottom-left-radius: 8px;
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        color: white;
        box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
        pointer-events: auto;
        position: relative;
        flex-shrink: 0;
      }

      .scout-action-tab img {
        width: 32px;
        height: 32px;
        object-fit: contain;
        filter: drop-shadow(0 1px 2px rgba(0,0,0,0.1)) brightness(0) invert(1);
      }

      .scout-action-tab:hover {
        transform: translateX(-4px);
        box-shadow: -4px 0 12px rgba(0, 0, 0, 0.15);
        width: 52px;
      }

      .scout-action-tab:active {
        transform: translateX(-2px);
      }

      .scout-action-tab.disabled {
        opacity: 0.5;
        cursor: not-allowed;
        filter: grayscale(1);
        transform: none !important;
        width: 48px !important;
      }

      /* eBay Tab - Green */
      .scout-tab-ebay {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%); /* Green */
      }

      /* PriceCharting Tab - Blue */
      .scout-tab-pricecharting {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); /* Blue */
      }

      /* Tooltip */
      .scout-action-tab::after {
        content: attr(data-tooltip);
        position: absolute;
        left: 100%;
        top: 50%;
        transform: translateY(-50%);
        margin-left: 12px;
        background-color: #202223;
        color: white;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 500;
        white-space: nowrap;
        opacity: 0;
        pointer-events: none;
        transition: all 0.2s ease;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        visibility: hidden;
      }

      .scout-action-tab:hover::after {
        opacity: 1;
        visibility: visible;
        margin-left: 16px;
      }
    `,C=()=>{if(!document.getElementById("scout-quick-actions-styles")){const t=document.createElement("style");t.textContent=m,t.id="scout-quick-actions-styles",(document.head||document.documentElement).appendChild(t)}};let p=null,l=null,d=null,s=null,c=null;const S=()=>{const t=document.querySelector('input[name="title"]');if(t){let e=t.parentElement;for(;e&&e!==document.body;){const o=(e.className||"").toString();if(o.includes("Polaris-ShadowBevel")||o.includes("Polaris-LegacyCard")||o.includes("Polaris-Card"))return e;if(e.tagName==="SECTION"||o.includes("Polaris-Box")){const n=window.getComputedStyle(e);if(n.backgroundColor==="rgb(255, 255, 255)"&&n.boxShadow!=="none")return e}e=e.parentElement}}return null},b=t=>{if(!t)return null;const e=t.querySelector('[class*="_ReadField_"]');if(e&&!e.className.includes("placeholder"))return e.textContent?.trim()||null;const o=t.querySelector("input");return o?o.value:null},y=()=>{const t=document.querySelector('[id*="metafields.custom.mpn"]')||document.querySelector('[id*="metafields.custom.manufacturer_part_number"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(o=>{const n=o.querySelector("label");return n&&n.textContent.includes("MPN")});l=b(t);const e=document.querySelector('[id*="metafields.custom.upc"]')||document.querySelector('[id*="metafields.custom.barcode"]')||document.querySelector('[id*="metafields.barcode"]')||Array.from(document.querySelectorAll('[id*="metafields"]')).find(o=>{const n=o.querySelector("label");return n&&(n.textContent.includes("UPC")||n.textContent.includes("Barcode"))});d=b(e)},h=t=>{c&&!c.closed&&c.close();const e=1100,o=800,n=(window.screen.width-e)/2,a=(window.screen.height-o)/2;c=window.open(t,"scout_search_popup",`width=${e},height=${o},left=${n},top=${a},resizable=yes,scrollbars=yes`)},q=()=>{if(document.getElementById("scout-quick-actions-overlay"))return;s=document.createElement("div"),s.id="scout-quick-actions-overlay",s.className="scout-quick-actions-overlay";const t=document.createElement("div");t.className="scout-action-tab scout-tab-pricecharting",t.id="scout-tab-pc";const e=document.createElement("img");e.src=i.pricecharting,e.alt="PriceCharting",t.appendChild(e),t.onclick=a=>{if(a.stopPropagation(),d){const r=`https://www.pricecharting.com/search-products?q=${encodeURIComponent(d)}&type=videogames`;h(r)}else alert("No UPC found")};const o=document.createElement("div");o.className="scout-action-tab scout-tab-ebay",o.id="scout-tab-ebay";const n=document.createElement("img");n.src=i.ebay,n.alt="eBay",o.appendChild(n),o.onclick=a=>{if(a.stopPropagation(),l){const r=`https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(l)}&LH_Sold=1&LH_Complete=1&_dmd=2&rt=nc`;h(r)}else alert("No MPN found")},s.appendChild(t),s.appendChild(o),document.body.appendChild(s)},k=()=>{if(p||(p=S()),!p||!s){s&&(s.style.opacity="0");return}const t=p.getBoundingClientRect();if(t.width===0||t.height===0){s.style.opacity="0";return}const o=t.left-48,n=t.top+60;s.style.left=`${o}px`,s.style.top=`${n}px`,s.style.opacity="1";const a=document.getElementById("scout-tab-pc"),r=document.getElementById("scout-tab-ebay");a&&(d?(a.classList.remove("disabled"),a.setAttribute("data-tooltip",`Search PriceCharting with UPC: ${d}`)):(a.classList.add("disabled"),a.setAttribute("data-tooltip","No UPC found"))),r&&(l?(r.classList.remove("disabled"),r.setAttribute("data-tooltip",`Search eBay(sold prices) with MPN: ${l}`)):(r.classList.add("disabled"),r.setAttribute("data-tooltip","No MPN found")))},f=()=>{k(),requestAnimationFrame(f)},g=()=>{C(),window.addEventListener("focus",()=>{c&&!c.closed&&(c.close(),c=null)}),new MutationObserver(()=>{y()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value","class"]}),q(),requestAnimationFrame(f),setInterval(y,2e3)},w=()=>{chrome.storage.sync.get(["cmdkSettings"],t=>{((t.cmdkSettings||{}).shopifyButtons?.enabled??!0)&&g()})};chrome.runtime.onMessage.addListener((t,e,o)=>{if(t.action==="shopify-buttons-settings-changed")if(t.enabled)if(!document.getElementById("scout-quick-actions-overlay"))g();else{const n=document.getElementById("scout-quick-actions-overlay");n&&(n.style.display="flex")}else{const n=document.getElementById("scout-quick-actions-overlay");n&&(n.style.display="none")}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",w):w()}};function P(){}function u(i,...m){}const v={debug:(...i)=>u(console.debug,...i),log:(...i)=>u(console.log,...i),warn:(...i)=>u(console.warn,...i),error:(...i)=>u(console.error,...i)};return(async()=>{try{return await x.main()}catch(i){throw v.error('The unlisted script "shopify-buttons" crashed on startup!',i),i}})()})();
shopifyButtons;