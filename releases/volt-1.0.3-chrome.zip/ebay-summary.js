var ebaySummary=(function(){"use strict";function G(e){return e}const E="sidepanel.html",y="__scoutSidePanelCtx__";function b(){const e=globalThis;return e[y]||(e[y]={state:{open:!1,tool:null},listenersAttached:!1}),e[y]}function x(e){if(e.tabId!==void 0)return;const o=()=>{if(e.tabId===void 0)try{chrome.runtime.sendMessage({action:"getSidePanelStateForTab"},n=>{!chrome.runtime.lastError&&n?.success?(typeof n?.tabId=="number"&&(e.tabId=n.tabId,console.log(`[Scout] Sidepanel context initialized with tabId: ${e.tabId}`)),n?.state&&(e.state=_(n.state))):setTimeout(o,1e3)})}catch{setTimeout(o,2e3)}};o(),$(e)}function $(e){if(!e.listenersAttached){try{chrome.runtime.onMessage.addListener((o,n,r)=>(o?.action==="sidePanelStateSync"&&(e.state=_(o?.state),r({ok:!0})),!1))}catch{}e.listenersAttached=!0}}function _(e){return!e||typeof e!="object"?{open:!1,tool:null}:{open:!!e.open,tool:typeof e.tool=="string"?e.tool:null}}function A(e){if(chrome?.sidePanel?.setOptions)try{const o={enabled:!0,path:E};typeof e=="number"&&(o.tabId=e),chrome.sidePanel.setOptions(o,()=>{const n=chrome.runtime.lastError;n&&console.warn("[Scout] setOptions warning:",n.message)})}catch{}}function B(e){return new Promise((o,n)=>{if(!chrome?.sidePanel?.open){n(new Error("sidePanel API unavailable"));return}try{const r={};typeof e=="number"&&(r.tabId=e),chrome.sidePanel.open(r,()=>{const a=chrome.runtime.lastError;a?n(a):o()})}catch(r){n(r)}})}function I(e){return new Promise((o,n)=>{if(!chrome?.sidePanel?.close){n(new Error("sidePanel API unavailable"));return}try{const r={};typeof e=="number"&&(r.tabId=e),chrome.sidePanel.close(r,()=>{const a=chrome.runtime.lastError;a?n(a):o()})}catch(r){n(r)}})}function p(e,o,n,r,a){try{chrome.runtime.sendMessage({action:"sidePanelToggleResult",status:e,tabId:o,tool:n,source:r,error:a},()=>{chrome.runtime.lastError})}catch{}}function S(){const e=!!chrome?.sidePanel?.open;return console.log(`[Scout] sidePanel API available: ${e}, tabId: ${b().tabId}`),e}function T(){try{const e=b();x(e)}catch{}}function z(e,o){if(!S())return Promise.reject(new Error("sidePanel API unavailable"));const n=b();x(n);const r=n.tabId,a=n.state||{open:!1,tool:null},m=a.open&&a.tool===e;return new Promise((h,g)=>{if(m){I(r).then(()=>{n.state={open:!1,tool:null},p("closed",r,e,o?.source),h("closed")}).catch(u=>{p("error",r,e,o?.source,u?.message),g(u)});return}try{chrome.storage?.local?.set?.({sidePanelTool:e,sidePanelUrl:null})}catch{}n.state={open:!0,tool:e},A(r),B(r).then(()=>{p("opened",r,e,o?.source),h("opened")}).catch(u=>{console.error("[Scout] execOpen failed:",u),n.state={open:!1,tool:null},p("error",r,e,o?.source,u?.message),g(u)})})}const U={matches:["https://www.ebay.com/sch/*"],runAt:"document_idle",allFrames:!1,main(){if(!window.location.hostname.includes("ebay.com")||!window.location.pathname.startsWith("/sch/")){console.log("⚡ [Volt eBay Summary] Not on eBay search page, exiting");return}T(),console.log("⚡ [Volt eBay Summary] SCRIPT LOADED");const e="volt-ebay-summary",o="volt-ebay-summary-style";let n=!1,r=!1;const a=(...t)=>{try{console.log("[Volt eBay Summary]",...t)}catch{}},m=t=>{try{chrome.runtime.sendMessage({action:"openInSidebar",tool:t})}catch{}},h=t=>{if(!S()){m(t);return}try{z(t,{source:"ebay-summary"}).catch(l=>{a("sidepanel trigger failed",l?.message||l),m(t)})}catch(l){a("sidepanel trigger threw",l?.message||l),m(t)}},g=()=>{if(document.getElementById(o))return;const t=document.createElement("style");t.id=o,t.textContent=`
        #${e} {
          width: 100%;
          padding: 16px 20px;
          border-radius: 10px;
          margin: 12px 0 0 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
          color: #0f172a;
          box-shadow: 0 4px 12px rgba(15, 23, 42, 0.05);
          position: relative;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        
        /* Green theme for Sold Listings */
        #${e}.volt-state-sold {
          border: 1px solid #16a34a; /* Green-600 */
          background: #f0fdf4; /* Green-50 */
        }
        
        /* Orange theme for Active/Completed Listings (Warning) */
        #${e}.volt-state-active {
          border: 1px solid #f97316; /* Orange-500 */
          background: #fff7ed; /* Orange-50 */
        }

        #${e} h2 {
          font-size: 18px;
          margin: 0;
          font-weight: 700;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        #${e} h2 img {
          width: 24px;
          height: 24px;
        }
        #${e} .volt-ebay-summary__content {
          font-size: 16px;
          color: #334155;
          line-height: 1.5;
        }
        #${e} .volt-ebay-summary__content strong {
          color: #0f172a;
          font-weight: 700;
        }
        #${e} .volt-ebay-summary__action {
          display: inline-block;
          margin-top: 8px;
          font-weight: 600;
          text-decoration: underline;
          cursor: pointer;
          color: #c2410c; /* Orange-700 */
          font-size: 15px;
        }
        #${e} .volt-ebay-summary__action:hover {
          color: #9a3412; /* Orange-800 */
        }

        #${e} .volt-ebay-summary__links {
          margin-left: 4px;
          color: #475569;
        }
        #${e} .volt-ebay-summary__links a {
          color: #15803d; /* Green-700 */
          text-decoration: underline;
          font-weight: 600;
          cursor: pointer;
        }
        #${e} .volt-ebay-summary__links a:hover {
          color: #166534; /* Green-800 */
        }

        #${e} .volt-ebay-summary__dismiss {
          position: absolute;
          top: 12px;
          right: 12px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__dismiss:hover {
          background: rgba(239, 68, 68, 0.1);
          color: #dc2626;
        }
        
        #${e} .volt-ebay-summary__sidepanel {
          position: absolute;
          top: 12px;
          right: 76px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__sidepanel:hover {
          background: rgba(59, 130, 246, 0.1);
          color: #2563eb;
        }
        
        /* Tooltip styles */
        [data-tooltip] {
          position: relative;
        }
        [data-tooltip]:hover::after {
          content: attr(data-tooltip);
          position: absolute;
          bottom: 100%;
          left: 50%;
          transform: translateX(-50%);
          margin-bottom: 8px;
          padding: 4px 8px;
          background: #0f172a;
          color: #f8fafc;
          border-radius: 4px;
          font-size: 12px;
          font-weight: 500;
          white-space: nowrap;
          z-index: 20;
          pointer-events: none;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        #${e} .volt-ebay-summary__settings {
          position: absolute;
          top: 12px;
          right: 44px;
          background: rgba(0, 0, 0, 0.05);
          border: none;
          border-radius: 6px;
          width: 24px;
          height: 24px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          line-height: 1;
          color: #64748b;
          transition: all 0.2s ease;
          z-index: 10;
        }
        #${e} .volt-ebay-summary__settings:hover {
          background: rgba(59, 130, 246, 0.1);
          color: #2563eb;
        }
      `,document.head.appendChild(t)},u=()=>{try{const t=new URL(window.location.href);if(!/\.ebay\./i.test(t.hostname)||!t.pathname.startsWith("/sch/"))return"unknown";const l=t.searchParams.get("LH_Sold"),c=t.searchParams.get("LH_Complete"),s=l==="1"||l==="true",i=c==="1"||c==="true";return s?"sold":i?"completed":"active"}catch{return"active"}},H=t=>{if(!t)return"All Conditions";const c=decodeURIComponent(t).split("|"),s=new Set;if(c.forEach(d=>{["1000","3","10"].includes(d)?s.add("New"):["1500","1750"].includes(d)?s.add("Open Box"):d>="2000"&&d<="2500"?s.add("Refurbished"):["3000","4","5000","6000"].includes(d)?s.add("Used"):["7000"].includes(d)?s.add("For Parts"):s.add("Other")}),s.size===0)return"All Conditions";const i=Array.from(s);return i.length<=2?i.join(" & "):i.join(", ")},w=()=>{const t=document.getElementById(e);t&&t.remove()},P=t=>{const c=t.target.closest("[data-action]");if(!c)return;const s=c.getAttribute("data-action");if(s){if(t.preventDefault(),t.stopPropagation(),s==="open-sidepanel")h("ebay-sold-tool");else if(s==="settings")chrome.runtime.sendMessage({action:"open-settings",section:"ebay"});else if(s==="dismiss")r=!0,w();else if(s==="switch-to-sold"){const i=new URL(window.location.href);i.searchParams.set("LH_Sold","1"),i.searchParams.set("LH_Complete","1"),window.location.href=i.toString()}else if(s==="filter-used"){const i=new URL(window.location.href);i.searchParams.set("LH_ItemCondition","3000"),window.location.href=i.toString()}else if(s==="filter-new"){const i=new URL(window.location.href);i.searchParams.set("LH_ItemCondition","1000"),window.location.href=i.toString()}else if(s==="filter-all"){const i=new URL(window.location.href);i.searchParams.delete("LH_ItemCondition"),window.location.href=i.toString()}}},R=()=>{let t=document.getElementById(e);if(t)return t;const l=document.querySelector(".srp-controls__row-2");if(l)return t=document.createElement("section"),t.id=e,t.addEventListener("click",P),l.appendChild(t),a("✓ Summary container inserted into .srp-controls__row-2"),t;const c=document.getElementById("srp-river-results");return!c||!c.parentElement?(a("✗ Cannot insert summary - no suitable parent found"),null):(t=document.createElement("section"),t.id=e,t.addEventListener("click",P),c.parentElement.insertBefore(t,c),a("✓ Summary container inserted before #srp-river-results (fallback)"),t)},k=async()=>{n=!1;try{if(!((await chrome.storage.sync.get(["cmdkSettings"])).cmdkSettings?.ebaySummary?.enabled??!0)){a("✗ eBay Summary feature is disabled in settings"),w();return}}catch(C){a("⚠️ Failed to check settings, assuming enabled",C)}if(r){w();return}g();const t=R();if(!t)return;const l=u(),c=l==="sold",i=new URL(window.location.href).searchParams.get("LH_ItemCondition");t.className=c?"volt-state-sold":"volt-state-active";let d="Active Listings";l==="sold"?d="Sold Listings":l==="completed"&&(d="Completed Listings (Sold & Unsold)");const L=H(i),M=chrome.runtime.getURL("assets/icons/logo-32.png");let v=`
        You are currently viewing <strong>${d}</strong> for <strong>${L}</strong> items.
      `;c?L==="All Conditions"&&(v+=`
            <div class="volt-ebay-summary__links">
              Want more accuracy? Filter by <a data-action="filter-used">Used</a> or <a data-action="filter-new">New</a>.
            </div>
          `):v+=`
          <div class="volt-ebay-summary__links">
            Ready to analyze prices? <a data-action="switch-to-sold">Switch to Sold Listings</a>.
          </div>
        `;const V=`
        <button class="volt-ebay-summary__sidepanel" data-action="open-sidepanel" data-tooltip="Open eBay Tool">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
          </svg>
        </button>
      `,D=`
        <button class="volt-ebay-summary__settings" data-action="settings" data-tooltip="Settings">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
          </svg>
        </button>
      `,F=`
        <button class="volt-ebay-summary__dismiss" data-action="dismiss" data-tooltip="Dismiss">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      `;t.innerHTML=`
        <h2>
          <img src="${M}" alt="Volt Logo" />
          eBay Summary
        </h2>
        <div class="volt-ebay-summary__content">
          ${v}
        </div>
        ${V}
        ${D}
        ${F}
      `};new MutationObserver(()=>{n||(n=!0,setTimeout(()=>{document.getElementById(e)||k()},1e3))}).observe(document.body,{childList:!0,subtree:!0}),setTimeout(k,1500)}};function j(){}function f(e,...o){}const O={debug:(...e)=>f(console.debug,...e),log:(...e)=>f(console.log,...e),warn:(...e)=>f(console.warn,...e),error:(...e)=>f(console.error,...e)};return(async()=>{try{return await U.main()}catch(e){throw O.error('The unlisted script "ebay-summary" crashed on startup!',e),e}})()})();
ebaySummary;